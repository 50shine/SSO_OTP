import os

os.system("python -m http.server 80")