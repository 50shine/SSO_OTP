
from func import main_menu

main_menu()


